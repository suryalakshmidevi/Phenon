package phenon.interview.phenon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhenonApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhenonApplication.class, args);
	}

}
